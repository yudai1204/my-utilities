document.getElementById("openall").addEventListener("click", function() {
    window.open("https://twitter.com/home");
    window.open("https://scombz.shibaura-it.ac.jp/lms/timetable");
    window.open("https://crowdworks.jp/dashboard");
    window.open("https://www.lancers.jp/mypage");
    window.open("https://www.chatwork.com/#!rid281339613");
});